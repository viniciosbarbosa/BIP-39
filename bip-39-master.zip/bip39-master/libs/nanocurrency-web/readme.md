Build (will create a bundle and copy it to /tmp/nano-util.js):

    npm install
    npm run build
