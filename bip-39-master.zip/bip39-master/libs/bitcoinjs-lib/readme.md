Build (will create a bundle and copy it to /tmp/bitcoinjs-lib.js):

    npm install
    npm run build
    manually add changes in https://github.com/iancoleman/bip39/commit/0702ecd3520c44cb8016f80329dcb5a3c8df88fc
